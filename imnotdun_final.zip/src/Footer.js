import React from 'react'
import {GrFacebookOption, GrInstagram, GrLinkedinOption, GrTwitter} from 'react-icons/gr';


const Footer = () => {
  return (
    <div >
      <div class="bg-blue-900  h-60 mt-8 flex  ">
          <div>
          <img src="/img/f1.png" class=" h-40 w-28 ml-7 pt-6" ></img>
          <select class=" ml-8 mt-5 bg-blue-900 text-white border-2 rounded-md h-8 w-40 border-white"><option class=" ml-1"> United states</option></select>
          </div>

          <div class="mt-8 ml-14 cursor-pointer  hover:underline hover: text-white">
              <h1 class=" font-bold text-white text-base font-sans">ABOUT</h1>
              <h3 class="text-white">Our Company</h3>
              <h3 class="text-white">Contact us</h3>
          </div>

          <div class="mt-8 ml-14 cursor-pointer">
              <h1 class=" font-bold text-white text-base font-sans">LEARN WITH US</h1>
              <h3 class="text-white">Courses</h3>
              <h3 class="text-white">IMNOTDUN for</h3>
              <h3 class="text-white">Employers</h3>
          </div>

          <div class="mt-8 ml-14">
              <h1 class=" font-bold text-white text-base font-sans">TEACH WITH US</h1>
              <h3 class="text-white">independent Teachers</h3>
          </div>

          <div class="mt-8 ml-14">
              <h1 class=" font-bold text-white text-base">PARTNER WITH US</h1>
              <h3 class="text-white">Channel Partners</h3>
              <h3 class="text-white">Investors</h3>
          </div>

          <div class="mt-8 ml-14">
              <h1 class=" font-bold text-white text-base">SUPPORT</h1>
              <h3 class="text-white text-sm">Privacy</h3>
              <h3 class="text-white text-sm">Terms</h3>
              <h3 class="text-white text-sm">Cookie Policy</h3>
              <h3 class="text-white text-sm"><p>Cancellation and</p><p>Refund Policy</p></h3>
          </div>

          <div class="mt-8 ml-14">
              <h1 class=" font-bold text-white text-base">FOLLOW US</h1>
            <span class="flex  text-white mt-5"> <GrLinkedinOption/>&nbsp;&nbsp;<GrFacebookOption/>&nbsp;&nbsp;<GrTwitter/>&nbsp;&nbsp;<GrInstagram/></span>
          </div>

          {/* <div class="mt-8 ml-14">
              <span class="bg-white "> <LinkedInIcon/></span>


          </div> */}



      </div>
    </div>
  )
}

export  default Footer
