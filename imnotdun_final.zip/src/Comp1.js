import React from 'react'
const Header = () => {
  return (
    <div>
      <section class="absolute z-50">
      <div class='fixed top-0 flex h-16 w-full text-xl font-sans  font-semibold bg-slate-50 items-center justify-between bg-newBrandWhite px-5 lg:px-10'>
      <div >
          <a href=''>
              <img src='/img/Logo.png' alt='logo' class="h-16 p-2"/>
          </a>
      </div>
      <div class=''>
      <ul class="md:flex lg:space-x-1 font-semibold text-lg leading-8 text-zinc-700 font-sans">
          <a href=''>Learn With Us</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href=''>Teach With Us</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href=''>Partner With Us</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href=''>Login/Sign Up</a>
      </ul>
      </div>
      <img src='/img/media.png' alt class='h-6 self-center md:hidden'/> 
      </div>
      </section>
    </div>
  )
}
export default Header