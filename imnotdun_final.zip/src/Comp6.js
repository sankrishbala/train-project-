import React from 'react'
import './Comp6.css'
const Comp6 = () => {
  return (
    <div>
      <div class="mx-auto max-w-5xl px-5">
<div class="flex items-center overflow-y-auto whitespace-nowrap py-4">
<a class="text-gray-900 hover:underline " href="/courses">Courses</a>
<span class=" text-fuchsia-600 mx-2 text-lg">/</span>
<span href="#" class=" text-gray-900 hover:underline ">Small Business Kickstarter: Succeeding in Services &amp; Retail</span>
</div>
</div>

<div class="">
<div class="mx-auto max-w-5xl ">
<div class="flex flex-col items-center  border-b px-5 py-8 md:flex-row">
<div class="align-top lg:w-2/3 lg:pr-4">
<h1 class=" mt-5 text-2xl font-semibold md:text-3xl lg:mt-0">Small Business Kickstarter: Succeeding in Services &amp; Retail</h1>
<div class="mt-2 text-left  text-base text-gray-800   sm:pr-28 ">Discover what it takes to develop a physical product and start a retail sales or service business from scratch.
</div>
<button class="   bg-fuchsia-600 mt-6 hidden rounded py-2 px-8 text-lg font-semibold text-white transition duration-500 focus:outline-none md:inline-block lg:px-12">ENROLL NOW</button>
</div>
<div class="align-top lg:w-1/3">
<img class="mt-10  object-cover object-center md:mt-0" alt="Course" src="https://careerladderbucket.s3.eu-west-2.amazonaws.com/users/b836e87c-7b7d-4521-86ca-be4bc9dc2b0a/profileImages/Brian%20Bair.jpg"></img>
<p>by<span class="pl-2 text-base font-bold">Bryan Bair  </span></p>
</div>
</div>
</div>
</div>

<div>
<div class=" mx-2  mb-4 max-w-5xl md:mx-auto mt-8 border-b ">
<div class="p-4"><p class="text-lg font-bold">About this course</p>
<div class=" htmlContent mr-0 mt-2 text-left   text-gray-800 sm:text-lg md:mr-40 lg:mr-80">
<p>The course objective is to allow students to gain relevant information on what it takes to develop a physical product and start a retail sales or service business. The course will discuss the physical, emotional and financial demands of starting a business and identify the resulting benefits to doing so. The content will help shorten the startup process and reduce the risks of starting a business. 
</p>&nbsp;
<p>After completing this course, you will be able to develop a roadmap for your business concept, and build confidence to ensure success in your new small business venture. The course content addresses the entrepreneurial mindset, debugging business ideas, business structures and legalities, customer understanding, the Lean business model to maximize value while minimizing waste, SWOT risk analysis, business modeling, marketing, and motivations to start a business.
</p>&nbsp;
<p> A highly personalized course, Bryan will provide live feedback on your business ideas and provide templates and additional resource materials that will help you launch anew venture.
</p>
</div>
</div>
</div>
</div>  

<section class=" mx-auto my-20  max-w-5xl">
<h1 class=" text-brandBlack mb-6 text-center text-3xl font-semibold md:text-3xl 2xl:text-4xl">Preview this course</h1>
<div class=" mx-auto md:h-[331px] md:w-[620px] 2xl:h-[600px] 2xl:w-[900px]">
<div class="  aspect-w-16 aspect-h-9 md:aspect-none mx-5 md:h-full md:w-full xl:mx-0 ">
<div class=" ">
<div class=" overflow: hidden;">
<iframe src="/videos/preview.html " style={{height:'350px', width:'600px ',  paddingLeft:'20px'}} >
</iframe>
</div>
</div>
</div>
</div>
</section>



<div class="bg-gray-200 ">
<div class="  max-w-5xl md:mx-auto">
<div class="py-12">
<p class="mx-5 mb-8 text-center text-3xl font-semibold md:mx-0 md:text-4xl">Who should take this course</p>
<div class=" mx-5 grid grid-cols-1  gap-y-8 sm:grid-cols-2 sm:gap-4  md:grid-cols-3 lg:mx-auto ">
<div class="card mx-auto bg-white w-[280px] shadow-md sm:w-full">
<div class="card-body  ">
<div class="numberCircle">1
</div>
<div class="card-text px-8 pb-8 font-semibold text-gray-800">Unemployed, retired or semi-retired individuals who want to execute a small business idea.
</div>
</div>
</div>
<div class="card mx-auto bg-white w-[280px] shadow-md sm:w-full">
<div class="card-body  ">
<div class="numberCircle">2</div>
<div class="card-text px-8 pb-8 font-semibold text-gray-800">People who wish to explore avenues for a second income.
</div>
</div>
</div>
<div class="card mx-auto bg-white w-[280px] shadow-md sm:w-full">
<div class="card-body  ">
<div class="numberCircle">3</div>
<div class="card-text px-8 pb-8 font-semibold text-gray-800">Individuals who wish to start a new and exciting venture, but are held back by  a lack of learned knowledge.
</div>
</div>
</div>
</div>
</div>
<div class="py-12">
<p class="mx-5 mb-8 text-center text-3xl font-semibold md:mx-0 md:text-4xl">Why you should enroll</p>
<div class=" mx-5 grid grid-cols-1  gap-y-8 sm:grid-cols-2 sm:gap-4  md:grid-cols-3 lg:mx-auto ">
<div class="card mx-auto bg-white w-[280px] shadow-md sm:w-full">
<div class="card-body  ">
<div class="numberCircle">1</div>
<div class="card-text px-8 pb-8 font-semibold text-gray-800">Learn how to draw your roadmap  and gain confidence to start a new small business.
</div>
</div>
</div>
<div class="card mx-auto bg-white w-[280px] shadow-md sm:w-full"><div class="card-body  ">
<div class="numberCircle">2</div>
<div class="card-text px-8 pb-8 font-semibold text-gray-800">Discover how to develop the right product for you and your potential customers.
</div>
</div>
</div>
<div class="card mx-auto bg-white w-[280px] shadow-md sm:w-full">
<div class="card-body  ">
<div class="numberCircle ">3</div>
<div class="card-text px-8 pb-8 font-semibold text-gray-800">Gain first hand feedback and advice on your business ideas from your trainer.
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="mx-auto max-w-4xl">
<div class=" border-b px-4 py-8">
<h1 class="mr-8 pb-6 text-center text-3xl font-semibold">Meet your Trainer</h1>
<div class="  flex flex-col justify-center md:flex-row ">
<div class="inline-block shrink-0  self-center align-top  md:self-start">
<img class=" w-48 object-cover object-center" alt="Course" src="https://careerladderbucket.s3.eu-west-2.amazonaws.com/users/b836e87c-7b7d-4521-86ca-be4bc9dc2b0a/profileImages/Brian%20Bair.jpg"></img>
</div>
<div class="mx-5  mt-5 inline-block align-top  md:mx-0 md:mt-0 md:pl-6">
<h1 class="text-2xl font-semibold">Bryan Bair  </h1>
<div class="htmlContent  mt-2 text-left text-base lg:text-lg ">
<p>Bryan Bair is a full time business trainer and adjunct professor based in Wasco, California. He received his MBA from Ashford University while working part-time and supporting his family. He began his career in facilities management and ended up managing the law firm Arter &amp; Haddenâ€™s Los Angeles office as an Operations Manager.
</p>
&nbsp;
<p>For many years he has worked with â€œCâ€ level contacts, helping organizations better utilize technology in facilities management by changing from paper to digital processes. He started his first business, a commercial inspection company, in 2010 and successfully ran it for 10 years before selling the business. 
</p>
&nbsp;
<p>For the last ten years he has been working with business owners helping evaluate new ventures and brand ideas.â€¯ He has taught entrepreneurship for five years at Brigham Young University, Idaho, helped develop the Business 101 course for Tell Library, and the dual credit program for High School and College students. Through direct experience, he has learned a lot about the potential for good, and bad in operating oneâ€™s own business. It is his goal to help and mentor others so they can avoid common pitfalls, empowering them to start a second life. 
</p>
</div>
</div>
</div>
</div>
</div>

<div class="mx-auto max-w-5xl">
<div class="items-center py-8 md:px-4">
<h1 class="mr-8 text-center text-3xl font-semibold">Session Details</h1>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top">
<p class="text-gray-500">1</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">What is my first step to start a business?</p>The entrepreneurial mindset and the idea inception 
 </div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top"><p class="text-gray-500">2</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">Who should I involve in my business?</p>How to structure a business, partners, the lean business model
</div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8"><div class="mt-1 inline-block w-1/12 align-top">
<p class="text-gray-500">3</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">What is my value?</p>Value proposition, customer segments and MVP
</div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top">
<p class="text-gray-500">4</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">What is my niche?</p>Product market fit and SWOT analysis</div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top"><p class="text-gray-500">5</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">What does my  business look like on paper?</p>Business Model Canvas </div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top">
<p class="text-gray-500">6</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">How do I market my business?</p>Sales funnel and get, keep, grow</div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top">
<p class="text-gray-500">7</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">What resources will I need?</p>Employees, finances and location</div>
</div>
<div class="mx-auto w-[85%] border-b-2 border-dotted border-borderGray py-8">
<div class="mt-1 inline-block w-1/12 align-top">
<p class="text-gray-500">8</p>
</div>
<div class="inline-block w-11/12 align-top">
<p class="pb-2 text-lg font-medium">Should I start a business and why?</p>Risks and rewards of business ownership, course reflection</div>
</div>
</div>
</div>

<div>
      <div class=" bg-gray-200 py-8 ">
<h2 class="pb-4  text-center text-3xl font-semibold text-black">Upcoming Batch Details</h2>
<div class="mt-4 hidden w-full overflow-auto  md:block lg:mx-auto lg:max-w-5xl">
<table class="w-full table-auto whitespace-nowrap uppercase ">
<thead class=" text-base text-black">
<tr><th class="txt-center   px-4 font-medium tracking-wider ">
</th>
<th class="txt-center   px-4 font-medium tracking-wider ">Start Date</th>
<th class="txt-center   px-4 font-medium tracking-wider ">Days</th>
<th class="txt-center   px-4 font-medium tracking-wider ">Time</th>
<th class="txt-center  w-32 px-4 font-medium tracking-wider ">Number of Sessions</th>
<th class="txt-center   w-40 rounded-tr-lg px-4 font-medium  tracking-wider">Price</th>
</tr>
</thead>
<tbody>
<tr class="text-black hover:bg-gray-200">
<td class="px-4 py-3">
<input type="radio" name="batch" value=''/>
</td>
<td class=" text-center font-bold text-black">
<p class="w-full  py-1 px-4 ">APR 21, 2022</p>
</td>
<td class="flex-wrap  px-4 text-center font-bold">
<span>Thu</span>
</td>
<td class="px-4  text-center font-bold">07:00 PM TO 08:00 PM EST</td>
<td class="px-4 text-center font-bold">8</td>
<td class="px-4 py-3 text-center font-bold">$40<br/>
<span class="text-sm font-medium"> </span>
</td>
</tr>
</tbody>
</table>
</div>
<div class="my-2 mx-2 cursor-pointer rounded-lg bg-white shadow-lg md:hidden">
<div class="flex  p-4 ">
<div class="text-customColor-titleText flex w-full flex-col md:flex-row ">
<div class="flex w-full flex-col md:w-1/2">
<div class="flex w-full justify-between text-gray-500">
<p class=" mb-1 text-xs font-medium">Start Date</p>
<p class=" mb-1 text-xs font-medium">Time</p>
</div>
<div class="flex w-full justify-between">
<p class=" text-fontColor-footerOrange text-sm font-semibold uppercase">APR 21, 2022</p>
<p class=" text-sm font-semibold">07:00 PM TO 08:00 PM EST</p>
</div>
<div class="mt-2 flex w-full justify-between text-gray-500">
<p class=" mb-1 text-xs font-medium">Days</p>
<p class=" mb-1 text-xs font-medium">Sessions</p>
</div>
</div>
<div class="flex w-full justify-between uppercase md:w-1/2">
<p class=" text-customColor-titleText flex flex-wrap text-sm font-medium">
<span class="mr-2">
<span>Thu</span>
</span>
 </p>
<p class=" text-sm font-medium"> 8</p>
</div>
</div>
</div>
<div class="flex flex-row items-center justify-between px-4 pb-4">
<div>
<div class="flex flex-col justify-center">
<p class="text-customColor-titleText font-bod flex flex-wrap text-xs text-gray-500">Price</p>
<p class="text-customColor-titleText text-base font-bold " >
<p class="text-customColor-titleText text-base font-bold ">$40<span class="text-sm font-medium"> 
</span>
</p>
</p>
</div>
</div>
<button class=" bg-fuchsia-600 flex  w-32 cursor-pointer items-center justify-center rounded-md border px-3 py-1 text-center text-sm font-medium text-white focus:outline-none sm:px-4 ">ENROLL NOW</button>
</div>
</div>
<div class="my-4 hidden w-full justify-center md:flex">
<button class=" bg-fuchsia-600 mt-6 hidden rounded py-2 px-8 text-lg font-semibold text-white transition duration-500 focus:outline-none md:block lg:px-12 ">ENROLL NOW</button>
</div>
</div>
    </div>

    <div class="items-center py-8 md:px-4">
<h1 class="mr-8 text-center text-3xl font-semibold">Frequently Asked Questions</h1>
<div class=" border-border-gray-200 mx-auto flex w-[85%] flex-col border-b py-8 text-base md:flex-row">
<div class=" mb-2 inline-block align-top md:mb-0 md:w-[40%]">
<p class="font-semibold text-black">Who is this course for?</p>
</div>
<div class="inline-block align-top md:w-[60%] md:pl-6">
<p class="font-normal pr-10">If you’ve ever had an idea for a small to medium retail or services business, this  secondly, how to do so. Anybody from any background is welcome to join, whether you’re a seasoned business veteran looking to branch out, or a low-experienced individual wishing to learn about starting a business.</p>
</div>
</div>
<div class="border-borderGray mx-auto flex w-[85%] flex-col border-b py-8 text-base md:flex-row">
<div class=" mb-2 inline-block align-top md:mb-0 md:w-[40%]">
<p class="font-semibold text-black">What’s your return policy?</p>
</div>
<div class="inline-block align-top md:w-[60%] md:pl-6">
<p class="font-normal">We’re happy to offer users a 100% refund after the first or second lesson if you decide that this isn’t the right course for you. All you have to do is get in touch with our support team via our Contact Us page.</p>
</div>
</div>
<div class="border-borderGray mx-auto flex w-[85%] flex-col border-b py-8 text-base md:flex-row">
<div class=" mb-2 inline-block align-top md:mb-0 md:w-[40%]">
<p class="font-semibold text-black">What if I miss a session? Can I watch it later?</p>
</div>
<div class="inline-block align-top md:w-[60%] md:pl-6">
<p class="font-normal">Yes, we record every session for users to download and watch again. If you miss a session, simply download the recording and study in your own time.</p></div></div><div class="border-borderGray mx-auto flex w-[85%] flex-col border-b py-8 text-base md:flex-row"><div class=" mb-2 inline-block align-top md:mb-0 md:w-[40%]"><p class="font-semibold text-black">What about when the course is over? Do you save the recordings?</p>
</div>
<div class="inline-block align-top md:w-[60%] md:pl-6">
<p class="font-normal">No, we discard all old recordings a set period after a course finishes to protect our users.</p>
</div>
</div>
<div class="border-borderGray mx-auto flex w-[85%] flex-col border-b py-8 text-base md:flex-row">
<div class=" mb-2 inline-block align-top md:mb-0 md:w-[40%]">
<p class="font-semibold text-black">Can I stay in contact with my peers and trainer once I’ve completed the course?</p>
</div>
<div class="inline-block align-top md:w-[60%] md:pl-6">
<p class="font-normal">Yes, of course! Some groups may offer public chat groups on social media or messaging services to stay in touch, and you are free to exchange contact information with other consenting platform users.</p>
</div>
</div>
<div class="border-borderGray mx-auto flex w-[85%] flex-col border-b py-8 text-base md:flex-row">
<div class=" mb-2 inline-block align-top md:mb-0 md:w-[40%]">
<p class="font-semibold text-black">What devices do I need to join the sessions?</p>
</div>
<div class="inline-block align-top md:w-[60%] md:pl-6">
<p class="font-normal">Your laptop or tablet should suffice, while your mobile / cell phone may also work. You may have to download and/or register on a video chat app such as Zoom to attend, though your trainer will confirm which communication platform when you enroll on your course. Ahead of every lesson, your trainer will email you the link to the virtual meeting.</p>
</div>
</div>
</div>

<p class=" text-newBrandBlack max-w-6xl px-5 pb-5 mt-5 mb-10">
Disclaimer - These courses are meant to provide an overview and purely for informational purposes. The course material has not been curated or verified by the platform operator. You are advised to consult your physician or financial advisors with respect to any of the course material that you wish to adopt.
</p>

<div class=" bg-yellow-400 fixed bottom-0 left-0 w-full border-t-2 py-4">
  <div class="customWidth text-fontColor-footerHeading mx-auto flex w-11/12 items-center justify-center">
    <div class="mt-4  hidden w-full  overflow-auto md:block lg:mx-auto">
      <div class=" mx-auto inline-block w-full align-top lg:w-4/5">
          <div class="inline-block  table-auto whitespace-nowrap uppercase flex ">
            <div class="ml-3">
              <h3 class="txt-center   px-4 font-medium tracking-wider ">Start Date</h3>
              <h3 class="w-full  py-1 px-4   font-bold text-gray-900">APR 21, 2022</h3>
            </div>
            <div class="ml-5">
              <h3 class="txt-center   px-4 font-medium tracking-wider">Days</h3>
              <h3 class="w-full  py-1 px-4   font-bold text-gray-900">Thu</h3>
            </div>
            <div class="ml-5">
              <h3 class="txt-center   px-4 font-medium tracking-wider ">Time</h3>
              <h3 class="px-4  text-center font-bold text-gray-900">07:00 PM TO 08:00 PM EST</h3>
            </div>
           <div class="ml-5">
              <h3 class="txt-center  w-32 px-4 font-medium tracking-wider ">Number of Sessions</h3>
              <h3 class="px-4 text-center font-bold">8</h3>
            </div>
          <div class=" ml-24">
            <h3 class="txt-center   -tr-lg w-40 px-4 font-medium   tracking-wider">Price</h3>
            <h3 class="px-4 py-3 text-center font-bold">$40</h3>&nbsp;
          </div>
<span class="text-sm font-medium"> </span>
</div>
</div>
<div class="mx-auto inline-block  w-full text-left md:text-center lg:w-1/5 ">
<button class=" bg-fuchsia-600 rounded     py-2 px-8 text-center text-lg font-semibold text-white transition duration-500 focus:outline-none lg:px-12 "> ENROLL NOW</button>
</div>
</div>
<div class="md:hidden">
<button class=" bg-fuchsia-600 rounded py-2 px-8 text-center text-lg font-semibold text-white transition duration-500 focus:outline-none lg:px-12 ">ENROLL NOW</button>
</div>
</div>
</div>  


    </div>
  )
}

export default Comp6
