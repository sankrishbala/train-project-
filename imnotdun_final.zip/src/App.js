import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Comp1 from './Comp1';
import Comp2 from './Comp2';
import Comp3 from './Comp3';
import Comp4 from './Comp4';
import Comp6 from './Comp6';
import Comp7 from './Comp7';
import Footer from './Footer';
import Footer1 from './Footer1'
import Section from './Section';
import Yellow from './Yellow';

function App() {
  return (
    <div class=" ">
     <Comp1/>
     <Comp2/>
     <Section/>
     <Footer1/>
     {/* <Comp3/>
     <Comp4/> 
      <Comp7/>  */}
     <Comp6/>
     
     {/* <Footer/> */}
     <Footer1/>
     {/* <Yellow/> */}
    </div>
  );
}

export default App;
