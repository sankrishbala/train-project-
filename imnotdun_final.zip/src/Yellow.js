import React from 'react'

const Yellow = () => {
  return (
    // <div class="bg-yellow-400 fixed bottom-0 left-0 w-full border-t-2 py-4  ">
        
    //     <span class=" font-sans  text-gray-900 text-base">Start Date</span>
      
    // </div>
    <div>
        <div class=" bg-yellow-400 fixed bottom-0 left-0 w-full border-t-2 py-4">
<div class="customWidth text-fontColor-footerHeading mx-auto flex w-11/12 items-center justify-center">
<div class="mt-4  hidden w-full  overflow-auto md:block lg:mx-auto">
<div class=" mx-auto inline-block w-full align-top lg:w-4/5">
<table class="inline-block  table-auto whitespace-nowrap uppercase ">
<thead class=" text-base text-black">
<tr>
<th class="txt-center   px-4 font-medium tracking-wider ">Start Date</th>
<th class="txt-center   px-4 font-medium tracking-wider">Days</th>
<th class="txt-center   px-4 font-medium tracking-wider ">Time</th>
<th class="txt-center  w-32 px-4 font-medium tracking-wider ">Number of Sessions</th>
<th class="txt-center   -tr-lg w-40 px-4 font-medium   tracking-wider">Price</th>
</tr>
</thead>
<tbody>
<tr class="text-black">
<td class=" text-center font-bold text-black">
<p class="w-full  py-1 px-4 ">APR 21, 2022</p>
</td>
<td class="flex-wrap  px-4 text-center font-bold">
<span>Thu</span>
</td>
<td class="px-4  text-center font-bold">07:00 PM TO 08:00 PM EST</td>
<td class="px-4 text-center font-bold">8</td>
<td class="px-4 py-3 text-center font-bold">$40&nbsp;
<span class="text-sm font-medium"> </span>
</td>
</tr>
</tbody>
</table>
</div>
<div class="mx-auto inline-block  w-full text-left md:text-center lg:w-1/5 ">
<button class=" bg-fuchsia-600 rounded     py-2 px-8 text-center text-lg font-semibold text-white transition duration-500 focus:outline-none lg:px-12 "> ENROLL NOW</button>
</div>
</div>
<div class="md:hidden">
<button class=" bg-fuchsia-600 rounded py-2 px-8 text-center text-lg font-semibold text-white transition duration-500 focus:outline-none lg:px-12 ">ENROLL NOW</button>
</div>
</div>
</div>
    </div>
  )
}

export default Yellow
