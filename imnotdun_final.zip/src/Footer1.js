import React from 'react'
import {GrFacebookOption, GrInstagram, GrLinkedinOption, GrTwitter} from 'react-icons/gr';
const Footer = () => {
  return (
    <div class=" bg-blue-900 p-6 pt-10 md:px-4  mb-40">
        <div class="flex flex-col-reverse lg:flex lg:flex-row">
        <div class="mx-auto mt-10 lg:mt-0 lg:w-[10%] ">
                 <img src="./img/f1.png" class="h-28"/>
                 <div class="hidden items-center justify-center lg:flex pt-2">
                 <select class="w-auto rounded-md border bg-transparent px-1py-2 text-center text-sm text-white p-1">
                        <option class="bg-transparent text-black" value="Us">United States</option>
                        <option class="bg-transparent text-black" value="Uk">United Kingdom</option>
                 </select>
             </div>
             </div>
             <div class="flex  justify-center items-center lg:hidden text-white">
                    <p class="text-md pt-4">Follow Us On</p>
                    <div class="flex">
                        <span class="flex  text-white mt-5  ">
                            <GrLinkedinOption/>&nbsp;&nbsp;
                            <GrFacebookOption/>&nbsp;&nbsp;
                            <GrTwitter/>&nbsp;&nbsp;
                            <GrInstagram/>
                        </span>   
                    </div>
            </div>
            <div class="flex items-center justify-center lg:hidden">
                 <select class="w-40 rounded-md border bg-transparent px-1py-2 text-center text-sm text-white p-2">
                        <option class="bg-transparent text-black" value="Us">United States</option>
                        <option class="bg-transparent text-black" value="Uk">United Kingdom</option>
                 </select>
             </div>
         <div class="grid grid-cols-2 gap-4 mt-6 lg:mt-0 md:flex  ">
                <div class=" text-white  mr-11">
                    <h3 class="uppercase font-bold ">About</h3>
                    <p class="mt-2 hover:underline"><a href="" >Our Company</a></p>
                    <p class="mt-2 hover:underline"><a href="">Contact Us</a></p>
                </div>
                <div class=" text-white">
                    <h3 class="uppercase font-bold ">learn with us</h3>
                    <p class="mt-2 hover:underline"><a href="" >Courses</a></p>
                    <p class="mt-2 hover:underline"><a href="" >IMNOTDUN for Employers</a></p>
                </div>
                <div class=" text-white">
                    <h3 class="uppercase font-bold ">Teach  with us</h3>
                    <p class="mt-2 hover:underline"><a href="">Independent Teachers</a></p>
                </div>
                <div class=" text-white">
                    <h3 class="uppercase font-bold ">Partner with us</h3>
                    <p class="mt-2 hover:underline"><a href="" >Channel Partners</a></p>
                    <p class="mt-2 hover:underline"><a href="" >Investors</a></p>
                </div>
                <div class=" text-white">
                    <h3 class="uppercase font-bold ">Support</h3>
                    <p class="mt-2 hover:underline"><a href="">Privacy</a></p>
                    <p class="mt-2 hover:underline"><a href="">Terms</a></p>
                    <p class="mt-2 hover:underline"><a href="">Cookie Policy</a></p>
                    <p class="mt-2 hover:underline"><a href="">Cancellation and Refund Policy</a></p>
                </div>
            </div>
            <div class=" hidden lg:flex">
                <div class="text-white">
                    <p class="text-sm">Follow Us On</p>
                    <div class="flex gap-2">
                        <span class="flex  text-white mt-5 gap-4 h-10">
                             <GrLinkedinOption/>
                             <GrFacebookOption/>
                             <GrTwitter/>
                             <GrInstagram/>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}
export default Footer