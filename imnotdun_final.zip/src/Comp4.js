import React from 'react'
import VideoF1 from './video1.mp4'
const Comp4 = () => {
  return (
    <div class=" md:flex ">
      <div class="box-content rounded bg-slate-50   ml-52 mr-52 m-2 justify-between mt-24 p-5 max-w-5xl mt-6  h-96  md:block">
      <div class="flex  ">
       <div class="flex-col ml-6" >
       <img src='/img/b2.jpg' class="rounded-full h-16 ml-6 mb-5 "></img>
       <button class=" box-content rounded-full w-28 h-9 bg-green-500 ml-0 text-white mb-6">ENROLL</button>
       <span class=" font-bold  pt-3 ml-6 ">$40</span>
       </div>

       <div class="w-[45%]">
        <p class="  text-base  font-bold md:mr-4 md:text-2xl  ">Investing In Emerging Tech &</p>
        <p class="  text-base  font-bold md:mr-4 md:text-2xl  mb-2">Tech Startups</p>
       <span class=" text-gray-700 sm:mr-20 md:mr-6 font-sans text-base   "><p>Discover what it takes to develop a physical</p> <p>product and start a retail sales or service business  </p><p >scratch.</p></span>
       <hr class="border-b border-fuchsia-600   "></hr> 
       <p >
        <span class="text-gray-700 text-sm">by</span>&nbsp;<span class=" text-lg font-semibold text-gray-700">Bryan Bair</span>
       </p>
       <span class=" text-gray-700  ">
          <p class="">Bryan Bair is a full time business trainer and</p><p class="mb-3"> adjunct professor based in Wasco, California.</p>
       </span>
       <hr class="border-b border-fuchsia-600 pt-0  mb-4 "></hr> 
       
      </div>
       
       <div class="hidden w-[40%] md:block">
         <div class="flex justify-center">
            <p class=" border-fuchsia-600 border-b-2 mt-2">Video</p>
         </div>
        <div class="mx-auto flex h-[220px] items-center justify-center w-[45%]">
          <div class=" ml-4">
            {/* <video controls class=" max-w-xs h-52 ml-5">
             <source src={VideoF1} type="video/mp4"/>
            </video> */}
            <iframe src="/videos/video1.mp4" style={{width:'350px',height:'175px'}}></iframe>
          </div>
      </div>
     </div>
</div>
     
      <div class="flex mt-10">
       <div class=" ml-10">
        <h3 class="text-gray-600">Start Date</h3>
        <h3 class=" font-bold font-sans text-gray-900">APR 21,2022</h3>
       </div>
       <div class=" ml-20">
        <h3 class="text-gray-600">Days</h3>
        <h3 class=" font-bold font-sans text-gray-900">Thu</h3>
       </div>
       <div class=" ml-20">
        <h3 class="text-gray-600">Duration</h3>
        <h3 class=" font-bold font-sans text-gray-900">60Mins</h3>
       </div>
       <div class=" ml-20">
        <h3 class="text-gray-600">Time</h3>
        <h3 class=" font-bold font-sans text-gray-900">07:00PM TO 08:00 PM EST</h3>
       </div>
       <div class=" ml-20">
        <h3 class="text-gray-600">Number of sessions </h3>
        <h3 class=" font-bold font-sans text-gray-900">8 sessions</h3>
       </div>
      </div>

  </div>       
</div>
  )
}

export default Comp4
