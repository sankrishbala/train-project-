import React, { useEffect } from "react";
import { Container } from "reactstrap";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setProducts } from "../redux/action/product-actions";
import ProductComponent from "./ProductComponent";

const ProductPage = () => {
  const dispatch = useDispatch();

  const products = useSelector((state) => state.allProducts.products);
  console.log("Products :", products);
  
  const fetchProducts = async () => {
    const response = await axios
      .get("https://fakestoreapi.com/products/category/electronics")
      .catch((err) => {
        console.log("Err: ", err);
      });
    dispatch(setProducts(response.data));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  
  return (
    <Container fluid style={{marginTop:"4.5rem"}}>
        <h4>React Redux Demo</h4>
      <ProductComponent />
    </Container>
  );
};

export default ProductPage;
