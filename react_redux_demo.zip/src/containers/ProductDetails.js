import React, { useEffect } from "react";
import { Button } from "reactstrap";
import axios from "axios";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {
  selectedProduct,
  removeSelectedProduct,
} from "../redux/action/product-actions";

const ProductDetails = () => {
  const dispatch = useDispatch();
  
  const { productId } = useParams();
  const product = useSelector((state) => state.selectedProduct);
  const { image, title, price, category, description } = product;
  
  const fetchProductDetail = async (id) => {
    const response = await axios
      .get(`https://fakestoreapi.com/products/${id}`)
      .catch((err) => {
        console.log("Err: ", err);
      });
    dispatch(selectedProduct(response.data));
  };

  useEffect(() => {
    if (productId && productId !== "") fetchProductDetail(productId);
    
    return () => {
      dispatch(removeSelectedProduct());
    };
  }, [productId]);
  return (
    <div
      className="card"
      style={{ width: "50%", margin: "0 auto", marginTop: "5rem" }}
    >
      <img className="card-img-top" src={image} alt="prod" />
      <div className="card-body">
        <h5 className="card-title">{title}</h5>
        <h5 className="card-subtitle">{category}</h5>
        <p class="card-text">{description}</p>
        <h5 className="card-title text-danger">${price}</h5>
        <Button color="success">Buy Now</Button>
      </div>
    </div>
  );
};

export default ProductDetails;
