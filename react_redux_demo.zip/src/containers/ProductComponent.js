import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const ProductComponent = () => {
  const products = useSelector((state) => state.allProducts.products);

  const renderList = products.map((product) => {
    const { id, title, image, price, category } = product;
    return (
      <div key={id} className="card" style={{ width: "18rem", margin: "1rem" }}>
        <img className="card-img-top" src={image} alt="prod" />
        <div className="card-body">
          <h5 className="card-title">{title}</h5>
          <h5 className="card-subtitle">{category}</h5>
          <h5 className="card-title text-danger">${price}</h5>
          <Link to={`/product/${id}`} className="btn btn-primary">
            View Details
          </Link>
        </div>
      </div>
    );
  });

  return <div className="d-flex align-content-end flex-wrap">{renderList}</div>;
};

export default ProductComponent;
