import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Container,
  Collapse,
  Nav,
  Navbar,
  NavbarBrand,
  NavbarToggler,
  NavItem,
  NavLink,
} from "reactstrap";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Container fluid className="navbar">
      <Navbar color="danger" dark expand="md" fixed="top" light>
        <NavbarBrand to="/" tag={Link} className="me-auto">
          <img
            src="https://dmdev.digitmarket.com/media/store2/1/tes.png"
            alt="logo"
            width={50}
          />
        </NavbarBrand>
        <NavbarToggler
          className="me-2"
          onClick={() => {
            setIsOpen(!isOpen);
          }}
        />
        <Collapse navbar isOpen={isOpen}>
          <Nav className="me-auto ps-5" navbar>
            <NavItem>
              <NavLink tag={Link} to="/">
                React Redux Demo
              </NavLink>
            </NavItem>
          </Nav>
        </Collapse>
      </Navbar>
    </Container>
  );
};

export default Header;
