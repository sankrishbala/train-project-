import { combineReducers } from "redux";
import { productsReducer, selectedProductsReducer } from "./products-reducer";
const reducers = combineReducers({
  allProducts: productsReducer,
  selectedProduct: selectedProductsReducer,
});
export default reducers;
