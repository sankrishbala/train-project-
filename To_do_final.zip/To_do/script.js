function submit() {
  var titlearray = [];
  var descriptionarray = [];
  var c_name = document.getElementById("cname").value;
  titlearray.push(c_name);
  var desc = document.getElementById("des").value;
  descriptionarray.push(desc);
  var country = document.getElementById("country").value;
  var takeimage = document.getElementById("fileInput").value;
  create_card(titlearray, descriptionarray, country, takeimage);
  c_name.innerHTML = "";
  desc.innerHTML = "";
}

var create_card = (titlearray, descriptionarray, num, takeimage) => {
  var dynamic = document.querySelector(".container");
  for (var i = 0; i < titlearray.length; i++) {
    var currency = num === "usa" ? "$" : num === "india" ? "₹" : "€";
    var fetch = document.querySelector(".container").innerHTML;
    dynamic.innerHTML =
      `<div id="cards${i}" class="boxes">
      <div class="box-content">
        <div id="image" ></div>
        <h2>${titlearray[i]}</h2>
        <p>
          ${descriptionarray[i]}
        </p>
        <a class="showmore" href="#">ReadMore</a>
        <p id="curr" ></p>
      </div>
    </div>` + fetch;
    document.getElementById("curr").innerHTML = currency + Math.floor(Math.random() * (1000 - 500 + 1) + 500);
    var fileviewarea = document.getElementById(`image`);
    var file = fileInput.files[0];
    var imageType = /image.*/;

    if (file.type.match(imageType)) {
      var reader = new FileReader();

      reader.onload = function (e) {
        fileviewarea.innerHTML = "";

        var img = new Image(120, 130);
        img.src = reader.result;

        fileviewarea.appendChild(img);
      };

      reader.readAsDataURL(file);
    } else {
      fileviewarea.innerHTML = "Invalid File type";
    }
  }
};
// var bgimg = document.getElementById(`cards${i}`);
// bgimg.style.backgroundImage = `url('img/${titlearray[i]}.jpg')`;

// "css","js","python","java","android","jquery","ruby"
// "css style","js program","python code","java objects","android program","jquery objects","ruby code"
